cd /home/x306/xn/caffe
./build/tools/caffe train \
--solver="../solver.prototxt" \
--weights="../VGG_ILSVRC_16_layers_fc_reduced.caffemodel" \
--gpu 0 2>&1 | tee ../log/VEDAI512_penlu_pr.log
